#!/bin/bash
/home/vishal/coding/redis/redis-6.0.1/src/redis-server /home/vishal/coding/redis/redis-6.0.1/stocks_db/redis.conf
